
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Project, Labour, Material, Equipment
from .serializers import ProjectSerializer,LabourSerializer,MaterialSerializer,EquipmentSerializer

class LabourView(APIView):
    def get(self, request):
        labours = Labour.objects.all()
        serializer = LabourSerializer(labours, many=True)
        return Response(serializer.data)
    def post(self, request):
        serializer = LabourSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, pk):
        labour = Labour.objects.get(pk=pk)
        serializer = LabourSerializer(labour, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        labour = Labour.objects.get(pk=pk)
        labour.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
class EquipmentView(APIView):
    def get(self, request):
        equipments = Equipment.objects.all()
        serializer = EquipmentSerializer(equipments, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = EquipmentSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def put(self, request, pk):
        equipments = Equipment.objects.get(pk=pk)
        serializer = EquipmentSerializer(equipments, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        equipments = Equipment.objects.get(pk=pk)
        equipments.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
class MaterialView(APIView):

    def post(self,request):
        serializer=MaterialSerializer(data=request.data)
        if serializer.is_valid():
             serializer.save()
             return Response(serializer.data,status=status.HTTP_201_CREATED)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
    def get(self, request):
        materials = Material.objects.all()
        serializer = MaterialSerializer(materials, many=True)
        return Response(serializer.data,status=status.HTTP_200_OK)
    def put(self, request, pk):
        material = Material.objects.get(pk=pk)
        serializer = MaterialSerializer(material, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def delete(self, request, pk):
        materials = Material.objects.get(pk=pk)
        materials.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class ProjectView(APIView):
    def get(self, request):
        projects = Project.objects.all()
        serializer = ProjectSerializer(projects, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = ProjectSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            labour_ids = request.data['labour_ids'].split(',')
            material_id = request.data['material_id']
            equipment_id = request.data['equipment_id']

            for labour_id in labour_ids:
                if labour_id in labour_ids:
                 labour = Labour.objects.get(id=int(labour_id))
                 labour.delete()
                else:
                    return Response({"Labour Not found"},status=status.HTTP_400_BAD_REQUEST) 
            material = Material.objects.get(id=int(material_id))
            if request.data['material_quantity'] < 0:
             material.quantity -= request.data['material_quantity']
             material.save()
            else:
                return Response({"Less Material Stock"},status=status.HTTP_400_BAD_REQUEST) 
            equipment = Equipment.objects.get(id=int(equipment_id))
            if request.data['equipment_quantity'] < 0:
             equipment.quantity -= request.data['equipment_quantity']
             equipment.save()
            else:
                return Response({"Less Equipment Stock"},status=status.HTTP_400_BAD_REQUEST) 
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


