from django.contrib import admin
from .models import Labour,Material,Equipment,Project,Profession
# Register your models here.
admin.site.register(Labour)
admin.site.register(Material)
admin.site.register(Equipment)
admin.site.register(Project)
admin.site.register(Profession)

